The extracted data is from an FMCSA Safety Measurement System (SMS) data.
Consists of Interstate and Intrastate Hazmat Motor Carriers.  File is comma delimited. One carrier per row.
Field Names and descriptions are listed below:

DOT_NUMBER               - US DOT Number of the Motor Carrier (Interstate and Intrastate Hazmat only)

INSP_TOTAL               - Total Number of Inspections for the measurement period (24 months)
DRIVER_INSP_TOTAL        - Total Number of Driver Inspections for the measurment period 
DRIVER_OOS_INSP_TOTAL    - Total Number of Driver Inspections containing at least one Driver Out-of-Service Violation
VEHICLE_INSP_TOTAL       - Total Number of Vehicle Inspections for the measurement period
VEHICLE_OOS_INSP_TOTAL   - Total Number of Vehicle Inspections containing at least one Vehicle Out-of-Service violation

UNSAFE_DRIV_INSP_W_VIOL  - Number of inspections with at least one Unsafe Driving BASIC violation 
UNSAFE_DRIV_MEASURE      - Unsafe Driving BASIC Roadside Performance Measure Value 
UNSAFE_DRIV_AC           - Unsafe Driving BASIC Acute/Critical Indicator (Y = Acute/Critical from investigation within previous 12 months) 

HOS_DRIV_INSP_W_VIOL     - Number of inspections with at least one Hours-of-Service BASIC violation
HOS_DRIV_MEASURE         - Hours-of-Service (HOS) Compliance BASIC Roadside Performance measure value  
HOS_COMPLIANCE_AC        - Hours-of-Service (HOS) Compliance BASIC Acute/Critical Indicator (Y = Acute/Critical from investigation within previous 12 months) 

DRIV_FIT_INSP_W_VIOL     - Number of inspections with at least one Driver Fitness BASIC violation
DRIV_FIT_MEASURE         - Driver Fitness BASIC Roadside Performance measure value  
DRIV_FIT_AC              - Driver Fitness BASIC Serious Violation Indicator (Y = Acute/Critical from investigation within previous 12 months) 

CONTR_SUBST_INSP_W_VIOL  - Number of inspections with at least one Controlled Substances and Alcohol BASIC violation
CONTR_SUBST_MEASURE      - Controlled Substances and Alcohol BASIC Roadside Performance measure value  
CONTR_SUBST_SV           - Controlled Substances and Alcohol BASIC Acute/Critical Indicator (Y = Acute/Critical from investigation within previous 12 months) 

VEH_MAINT_INSP_W_VIOL    - Number of inspections with at least one Vehicle Maintenance BASIC violation
VEH_MAINT_MEASURE        - Vehicle Maintenance BASIC Roadside Performance measure value  
VEH_MAINT_AC             - Vehicle Maintenance BASIC Acute/Critical Indicator (Y = Acute/Critical from investigation within previous 12 months) 